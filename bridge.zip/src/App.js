import Home from "./pages/Home";
import "./App.css";
import "./styling/mobile.css";

function App() {
  return (
    <>
      <Home />
    </>
  );
}

export default App;
